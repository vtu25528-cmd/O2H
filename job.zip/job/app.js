// Hamburger Menu

const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

menuBtn.addEventListener("click", () => {
    navLinks.classList.toggle("active");
});

// Dark Mode

const themeBtn = document.getElementById("themeBtn");

if(localStorage.getItem("theme") === "light"){
    document.body.classList.add("light-mode");
    themeBtn.innerHTML = "☀️";
}

themeBtn.addEventListener("click", () => {

    document.body.classList.toggle("light-mode");

    if(document.body.classList.contains("light-mode")){
        localStorage.setItem("theme","light");
        themeBtn.innerHTML = "☀️";
    }else{
        localStorage.setItem("theme","dark");
        themeBtn.innerHTML = "🌙";
    }

});

// Job Portal

const jobList = document.getElementById("jobList");
const loadingSection = document.getElementById("loadingSection");
const errorMessage = document.getElementById("errorMessage");

const searchInput = document.getElementById("searchInput");
const locationFilter = document.getElementById("locationFilter");
const companyFilter = document.getElementById("companyFilter");

const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const pageNumber = document.getElementById("pageNumber");

let jobs = [];
let filteredJobs = [];

let currentPage = 1;
const jobsPerPage = 6;

// Fetch Mock API

async function fetchJobs(){

    try{

        const response = await fetch(
        "https://jsonplaceholder.typicode.com/users"
        );

        if(!response.ok){
            throw new Error("Failed to fetch data");
        }

        const data = await response.json();

        jobs = data.map(user => ({
            title:"Frontend Developer",
            company:user.company.name,
            location:user.address.city,
            email:user.email
        }));

        filteredJobs = [...jobs];

        populateFilters();

        loadingSection.style.display = "none";

        displayJobs();

    }
    catch(error){

        loadingSection.style.display = "none";

        errorMessage.innerText =
        "Unable to load job listings.";

    }

}

// Populate Filters

function populateFilters(){

    const locations =
    [...new Set(jobs.map(job => job.location))];

    const companies =
    [...new Set(jobs.map(job => job.company))];

    locations.forEach(location => {

        locationFilter.innerHTML +=
        `<option value="${location}">
        ${location}
        </option>`;

    });

    companies.forEach(company => {

        companyFilter.innerHTML +=
        `<option value="${company}">
        ${company}
        </option>`;

    });

}

// Display Jobs

function displayJobs(){

    jobList.innerHTML = "";

    let start =
    (currentPage - 1) * jobsPerPage;

    let end =
    start + jobsPerPage;

    let pageJobs =
    filteredJobs.slice(start,end);

    pageJobs.forEach(job => {

        jobList.innerHTML += `
        <div class="job-card">

            <h3>${job.title}</h3>

            <p>
            <strong>Company:</strong>
            ${job.company}
            </p>

            <p>
            <strong>Location:</strong>
            ${job.location}
            </p>

            <p>
            <strong>Email:</strong>
            ${job.email}
            </p>

            <button class="apply-btn">
            Apply Now
            </button>

        </div>
        `;

    });

    pageNumber.innerText = currentPage;

}

// Search & Filters

function filterJobs(){

    const searchValue =
    searchInput.value.toLowerCase();

    filteredJobs = jobs.filter(job => {

        const titleMatch =
        job.title.toLowerCase()
        .includes(searchValue);

        const locationMatch =
        locationFilter.value === "" ||
        job.location === locationFilter.value;

        const companyMatch =
        companyFilter.value === "" ||
        job.company === companyFilter.value;

        return titleMatch &&
               locationMatch &&
               companyMatch;

    });

    currentPage = 1;

    displayJobs();

}

searchInput.addEventListener(
"input",
filterJobs
);

locationFilter.addEventListener(
"change",
filterJobs
);

companyFilter.addEventListener(
"change",
filterJobs
);

// Pagination

prevBtn.addEventListener("click", () => {

    if(currentPage > 1){

        currentPage--;

        displayJobs();

    }

});

nextBtn.addEventListener("click", () => {

    const totalPages =
    Math.ceil(
    filteredJobs.length /
    jobsPerPage
    );

    if(currentPage < totalPages){

        currentPage++;

        displayJobs();

    }

});

// Contact Form Validation

document.getElementById("contactForm")
.addEventListener("submit",(e)=>{

    e.preventDefault();

    let valid = true;

    const name =
    document.getElementById("name")
    .value.trim();

    const email =
    document.getElementById("email")
    .value.trim();

    const message =
    document.getElementById("message")
    .value.trim();

    document.getElementById("nameError")
    .innerText = "";

    document.getElementById("emailError")
    .innerText = "";

    document.getElementById("messageError")
    .innerText = "";

    if(name === ""){

        document.getElementById("nameError")
        .innerText = "Name Required";

        valid = false;
    }

    const pattern =
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if(!pattern.test(email)){

        document.getElementById("emailError")
        .innerText = "Invalid Email";

        valid = false;
    }

    if(message === ""){

        document.getElementById("messageError")
        .innerText = "Message Required";

        valid = false;
    }

    if(valid){

        alert(
        "Message Sent Successfully!"
        );

        document.getElementById(
        "contactForm"
        ).reset();

    }

});

// Start App

fetchJobs();